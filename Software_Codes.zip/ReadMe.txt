This file containts the two code related to the experiments performed. 
The amazon folder contains the transfer learning module for initialization of the initial global model.
The Baseline folder contains the baselines codes mentioned in the paper.
The Centralized folder contains the experiments for the Centralized setting modules.
The The NIID folder contains the experiments for the Federated learning non-IID setting modules.
The IID folder contains the experiments for the Federated learning IID setting modules.
All the codes related to the experiments are .ipynb files.
